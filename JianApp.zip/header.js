function Header({ Ellry Cafe Charging Port Tracker, Track and manage charging port usage in real-time. }) {
  return `
    <header class="app-header">
      <h1>${title}</h1>
      ${description ? <p class="description">${description}</p> : ""}
    </header>
  `;
}
