function ChargingPort({
  id,
  isOccupied,
  timeIn,
  timeOut,
  fee,
  onStartSession,
  onEndSession,
}) {
  return `
    <div class="port">
      <h3>Port ${id}</h3>
      <p>Status: ${isOccupied ? "Occupied" : "Available"}</p>
      ${
        isOccupied
          ? `
            <p>Time In: ${timeIn.toLocaleTimeString()}</p>
            <button class="end-session" onclick="endSession(${id})">End Session</button>
          `
          : `
            <button onclick="startSession(${id})">Start Session</button>
          `
      }
      ${
        timeOut
          ? `
            <p>Time Out: ${timeOut.toLocaleTimeString()}</p>
            <p class="fee">Fee: ₱${fee.toFixed(2)}</p>
          `
          : ""
      }
    </div>
  `;
}