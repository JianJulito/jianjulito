function ChargingPort({
  id,
  isOccupied,
  timeIn,
  timeOut,
  fee,
  onStartSession,
  onEndSession,
}) {
  return `
    <div class="port">
      <h3>Port ${id}</h3>
      <p>Status: ${isOccupied ? "Occupied" : "Available"}</p>
      ${
        isOccupied
          ? `
            <p>Time In: ${timeIn.toLocaleTimeString()}</p>
            <button class="end-session" onclick="endSession(${id})">End Session</button>
          `
          : `
            <button onclick="startSession(${id})">Start Session</button>
          `
      }
      ${
        timeOut
          ? `
            <p>Time Out: ${timeOut.toLocaleTimeString()}</p>
            <p class="fee">Fee: ₱${fee.toFixed(2)}</p>
          `
          : ""
      }
    </div>
  `;
}

class App {
  constructor(root) {
    this.root = root;
    this.ports = Array.from({ length: 10 }, (_, index) => ({
      id: index + 1,
      isOccupied: false,
      timeIn: null,
      timeOut: null,
      fee: 0,
    }));
    this.render();
  }

  updatePort(id, updates) {
    this.ports = this.ports.map((port) =>
      port.id === id ? { ...port, ...updates } : port
    );
    this.render();
  }

  render() {
    this.root.innerHTML = `
      ${Header({
        title: "Ellry Cafe Charging Port Tracker",
        description: "Track and manage charging port usage in real-time.",
      })}
      ${this.ports
        .map(
          (port) =>
            `<div id="port-${port.id}">
              ${ChargingPort({
                id: port.id,
                isOccupied: port.isOccupied,
                timeIn: port.timeIn,
                timeOut: port.timeOut,
                fee: port.fee,
                onStartSession: () => this.startSession(port.id),
                onEndSession: () => this.endSession(port.id),
              })}
            </div>`
        )

        method_name: function(attribute) {
          
        },
        .join("")}
    `;
  }

  startSession(id) {
    const now = new Date();
    this.updatePort(id, { isOccupied: true, timeIn: now, timeOut: null, fee: 0 });
  }

  endSession(id) {
    const now = new Date();
    const port = this.ports.find((p) => p.id === id);
    if (port.timeIn) {
      const elapsedHours = Math.ceil((now - port.timeIn) / (1000 * 60 * 60));
      const fee = elapsedHours * 10;
      this.updatePort(id, { isOccupied: false, timeOut: now, fee });
    }
  }
}

window.startSession = (id) => app.startSession(id);
window.endSession = (id) => app.endSession(id);

const rootElement = document.getElementById("app");
const app = new App(rootElement);